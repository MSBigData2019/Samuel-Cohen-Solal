##
* https://towardsdatascience.com/song-popularity-predictor-1ef69735e380  : A LIRE 
* https://towardsdatascience.com/billboard-hot-100-analytics-using-data-to-understand-the-shift-in-popular-music-in-the-last-60-ac3919d39b49 : Article data billboard A LIRE 
* https://www.themusicmaze.com/list-of-music-service-apis-and-analytics-websites/   : Liste API Musique
* https://developer.spotify.com/documentation/web-api/reference/tracks/get-audio-features/  : API Spotify
* https://labrosa.ee.columbia.edu/millionsong/  :  DATASET ? The Million Song Dataset is a freely-available collection of audio features and metadata for a million contemporary popular music tracks.
* 
* https://developer.spotify.com/documentation/web-api/quick-start/  : tuto API Spotify
