### Schedule
| De    | à     | tache |
| ------|:-----:| -----:|
| 8:30  | 9:30  | Exploration des données                   |
| 9:30  | 9:45  | Décision du sujet                         |
| 9:45  | 11:45 | Exploration des données / Analyse         |
| 11:45 | 12:15 | MANGER                                    |
| 12:15 | 14:30 | Exploration des données / Analyse( suite) |
| 14:30 | 15:50 | Dataviz + Story Telling                   |