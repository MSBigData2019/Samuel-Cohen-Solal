# Hackaton Musique
---

## Sujet : Comment construire le hit de l'année 2019 
***
### Sujet qu'on choisit : Déterminer la chanson de l'été 2019 en EUROPE/AMERIQUE DU NORD (on se focus sur les 18-30 ans et les plateformes de streaming)

#### Aspects : 
* **Tendance** 
* **Style** 
* **Pays/ Public/ Cible (Age)** (*Amérique du Nord/Europe*)
* **Popularité / chanteur -  groupe**
* **Période de l'année**
* **Musicalité/ Structure  ( BPM ,  Accords ...)**
* Plateforme (promotion , **stream**)
* Marketing (Label, Indé...)
* Langue

#### Data
* Youtube, Spotify
* Charts (Billborads ...)
* Résaux Sociaux ( Tweets ..)
